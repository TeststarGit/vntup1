// Generic function to fetch and display JSON data
async function fetchAndDisplayJSON(filePath, targetElementId, renderFunction) {
    try {
      const response = await fetch(filePath);
      const data = await response.json();
      renderFunction(data, targetElementId);
    } catch (error) {
      console.error('Error fetching JSON:', error);
    }
  }
  
  // Example render function for recent posts
  function renderRecentPosts(data, targetElementId) {
    const container = document.getElementById(targetElementId);
    if (!container) return;
  
    let html = '<ul>';
    data.forEach(post => {
      html += `<li><a href="${post.url}">${post.title}</a> (${post.date})</li>`;
    });
    html += '</ul>';
  
    container.innerHTML = html;
  }
  
  // Example render function for featured posts
  function renderFeaturedPosts(data, targetElementId) {
    const container = document.getElementById(targetElementId);
    if (!container) return;
  
    let html = '<div class="featured-posts">';
    data.forEach(post => {
      html += `
        <div class="post-card">
          <h3><a href="${post.url}">${post.title}</a></h3>
          <p>${post.excerpt}</p>
        </div>
      `;
    });
    html += '</div>';
  
    container.innerHTML = html;
  }
  
  // Call functions to fetch JSON and render
  document.addEventListener('DOMContentLoaded', () => {
    fetchAndDisplayJSON('assets/data/recentPosts.json', 'recent-posts', renderRecentPosts);
    fetchAndDisplayJSON('assets/data/featuredPosts.json', 'featured-posts', renderFeaturedPosts);
  });


  // Render function for tags
function renderTags(data, targetElementId) {
  const container = document.getElementById(targetElementId);
  if (!container) return;

  let html = '<div class="tags">';
  data.forEach(tag => {
    // Make a simple URL based on tag name (lowercase, no spaces)
    const pageUrl = generateTagUrl(tag);
    html += `<a href="${pageUrl}" class="tag">${tag}</a>`;
  });
  html += '</div>';

  container.innerHTML = html;
}

// Helper function to generate a page URL based on the tag name
function generateTagUrl(tagName) {
  const slug = tagName.toLowerCase().replace(/\s+/g, '') + '.html'; // remove spaces
  return 'pages/' + slug;
}
